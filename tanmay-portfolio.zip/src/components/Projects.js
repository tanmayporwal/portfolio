import React from "react";
import project1 from "../one.jpeg";


const Projects = () => {
    return (
        <div id="projects" className="container-projects py-4">
            <div className="row">
                <div class="col-full">
                    <h2 class="project-title">Projects</h2>
                    <div class="centered line"></div>
                </div>
            </div>

            <div className="row my-5">
                <div className="col-lg-6 col-xm-12">
                    <div className="proj-name-container " > 
                        <p className="project-name">Peer-To-Peer File Sharing Application: BitTorrent</p>
                    </div>
                    <div className="proj-desc-container">
                        <p className=" project-para ">
                            <strong>  Tenure: 1.5 Months</strong> <br></br>
                            <strong>  Technology Used: Java, Socket-programming, Git </strong> <br></br>
                            Developed file distribution application for peer-to-peer architecture using
                            multi-threading and socket programming in Java which follows BitTorrent like protocols.
                            Implemented choke-unchoke mechanism to prioritize peerselection for improved transmission
                            efficiency. Peer selection for unchoking is based on their downloading speed in the previous quantum (time slot), higher downloading speed will be prioritized more. I learned a lot about requirement gathering and class design in this project. </p>
                    </div>
                </div>

                <div className="col-lg-6 col-xm-12">
                    <div className="project-wrap mb-5 ">
                        <img className="project-img" src={project1} alt="My image" />                        
                    </div>
                </div>

            </div>            
        </div>
    )
}

export default Projects
