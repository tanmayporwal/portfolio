import React, { useState } from "react";
import emailjs from "emailjs-com";
import { useForm } from "react-hook-form";

const Contacts = () => {

  const { register, handleSubmit, errors } = useForm();

  const serviceID = "service_ID";
  const templateID = "template_ID";
  const userID = "user_fT60e5ZC2WsgexzUu26T2";


  const sendEmail = (e) =>  {
    e.preventDefault();

    emailjs.sendForm(serviceID, templateID, e.target, userID)
      .then((result) => {
          console.log(result.text);
      }, (error) => {
          console.log(error.text);
      });
  }


  return (
    <div id="contact_me" className="contact">
            <div className="text-center">
                <h1 className="contact-heading">contact me</h1>
                <div class="centered line contact-line"></div>
                <p className="para-data"> Thank you for having a look at my portfolio. Please reach out to me if you think I am good at web development.</p>
            </div>

            <span className="success-message">
                
            </span>

            <div className="text-center container">
                <form onSubmit={sendEmail}>
                <div className="row">
                    <div className="form">
                        <input
                        type="text"
                        className="form-control"
                        placeholder="Name."
                        name="name"
                        
                        />
                        <span className="error-message">
                            
                        </span>
                        <input
                        type="email"
                        className="form-control"
                        placeholder="Email."
                        name="email"
                       
                        />

                        <span className="error-message">
                            
                        </span>

                        <input
                        type="text"
                        className="form-control"
                        placeholder="Subject."
                        name="subject"
                        
                        />

                        <span className="error-message">
                            
                        </span>

                        <textarea
                        type="text"
                        className="form-control"
                        placeholder="Message."
                        name="description"
                        >
                        </textarea>
                        <span className="error-message">
                            
                        </span>
                        <button className="btn-main-offer contact-btn mb-5" type="submit">Send</button>
                    </div>
                    
                </div>
                </form>
            </div>
        </div>
  )
}

export default Contacts;
